from flask import Flask, render_template, jsonify, request, redirect, url_for
import json

import matplotlib
matplotlib.use('Agg') 

import subprocess

import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'  # Suppress TensorFlow logs

app = Flask(__name__)

# Route for the introductory page (default page)
@app.route('/')
def intro():
    return render_template('intro.html')

# Route for the home page where the reviews are displayed
@app.route('/home')
def home():
    with open('processed_reviews.json') as f:
        reviews = json.load(f)
        for review in reviews:
            review["rating"] = int(review["rating"])
    return render_template('index.html', reviews=reviews)

# Route for the comparison page
@app.route('/comparison')
def comparison():
    return render_template('comparison.html')
@app.route('/compare', methods=['POST'])
def compare():
    data = request.get_json()
    restaurant_link = data.get('restaurantLink')

    if not restaurant_link:
        return jsonify({'message': 'No restaurant link provided'}), 400

    #

        # Print all collected reviews
    print("abc")
    
    subprocess.run(['python', 'your_script.py', restaurant_link])
  
    return render_template('comparison.html')



if __name__ == '__main__':
    app.run(debug=True)
