 # The first argument is always the script name, so the second is our variable
import sys


# Get the variable passed from Flask
my_variable = sys.argv[1]  # The first argument is always the script name, so the second is our variable


from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
import json
import matplotlib.pyplot as plt
import time
import os
import numpy as np
from datetime import date
import pandas as pd
from datetime import timedelta


def parse_date(date_str):
    if 'Dined on' in date_str:  # Exact date
        return pd.to_datetime(date_str.replace('Dined on ', ''))
    elif 'Dined today' in date_str:  # 'Dined today'
        return pd.to_datetime('today')
    elif 'Dined' in date_str:  # Relative date like 'Dined 1 day ago'
        days_ago = int(date_str.split()[1])  # Extract the number of days ago
        return pd.to_datetime('today') - timedelta(days=days_ago)
today = date.today()

# Format the date as "DD-MM-YYYY"
formatted_date = today.strftime("%d-%m-%Y")
todaydate=0
day=""
day=formatted_date[0]+formatted_date[1]
todaydate+=(int(day))
day=""
day=formatted_date[3]+formatted_date[4]
todaydate+=(int(day)*30)
day=""
day=formatted_date[6]+formatted_date[7]+formatted_date[8]+formatted_date[9]
todaydate+=(int(day)*365)


# Set up the WebDriver
driver = webdriver.Chrome()

# Open the website
url ="https://www.opentable.com/r/verona-restaurant-texarkana?originId=9559ad0a-6f83-4a27-9b06-ab7546f6f6e9&corrid=9559ad0a-6f83-4a27-9b06-ab7546f6f6e9&avt=eyJ2IjoyLCJtIjoxLCJwIjowLCJzIjowLCJuIjowfQ&p=2&sd=2024-12-10T22%3A30%3A00#menu"
driver.get(my_variable)
meow=0
all_reviews = []  # List to store all reviews

try:
    while True:  # Loop through pagination until the last page
        # Extract reviews from the current page
        reviews_section = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.ID, "restProfileReviewsContent"))
        )
        print("mil gya")
        #time.sleep(5)
        reviews = reviews_section.find_elements(By.CSS_SELECTOR, "li.afkKaa-4T28-")
        #time.sleep(5)
        for review in reviews:
            print("a")
            date = review.find_element(By.CSS_SELECTOR, "p.iLkEeQbexGs-").text
            print("b")
            # Extract the review content
            content = review.find_element(By.CSS_SELECTOR, ".l9bbXUdC9v0-").text.strip()

            print("c")
            # Extract the overall rating
            rating = review.find_element(By.XPATH, ".//li[normalize-space(text())='Overall']/span").text
            print("d")
            resname=driver.title
            print("e")
            # Append the extracted information to the reviews list
            all_reviews.append({
                "date": date,
                "content": content,
                "rating": rating,
                "restaurant":resname
            })
        print(f"Extracted {len(reviews)} reviews from this page. Total: {len(all_reviews)}")
        if len(all_reviews) % 500 == 0:  # Clear data every 500 reviews
            driver.delete_all_cookies()

        # Locate the "Next" button
        try:
            next_button = WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.CSS_SELECTOR, 'a[aria-label="Go to the next page"]'))
            )
          
          
            
           
            if next_button.is_displayed() and next_button.is_enabled():
                #print("The 'Next' button is clickable")
                driver.execute_script("arguments[0].click();", next_button)
            else:
                break
                print("The 'Next' button is not clickable")
                
            
        except Exception as e:
            break
            print(f"Error: {e}")


except Exception as e:
    print("Error:", e)



with open("reviews_oftemporary.json", "w", encoding="utf-8") as json_file:
    json.dump(all_reviews, json_file, ensure_ascii=False, indent=4)

rating1=[]
rating2=[]
date1=[]
dare2=[]
with open('processed_reviews.json',"r",encoding="utf-8") as f:
    reviews = json.load(f)
    for review in reviews:
        rating2.append(int(review['rating']))
        dare2.append(review['date'])
            
        
with open('reviews_oftemporary.json',"r",encoding="utf-8") as f:
    reviews = json.load(f)
    for review in reviews:
        rating1.append(int(review['rating']))
        date1.append(review['date'])
date1 = [parse_date(date) for date in date1]
df = pd.DataFrame({
    'date': date1,
    'rating': rating1
})
def getperiod(mont):
    if mont<=2:
        return "jan-feb"
    elif mont<=4:
        return "mar-apr"
    elif mont<=6:
        return "may-jun"
    elif mont<=8:
        return "jul-aug"
    elif mont<=10:
        return "sep-oct"
    else:
        return "nov-dec"
period_order = {
    "jan-feb": 1,
    "mar-apr": 2,
    "may-jun": 3,
    "jul-aug": 4,
    "sep-oct": 5,
    "nov-dec": 6
}



df['year'] = df['date'].dt.year
df['month'] = df['date'].dt.month

df['period'] = df['month'].apply(getperiod)


avg_rating = df.groupby(['period', 'year'])['rating'].mean().reset_index()


avg_rating['period_year'] = avg_rating['period'] + ' ' + avg_rating['year'].astype(str)


final_result = avg_rating[['period_year', 'rating']]


final_result['sort_key'] = final_result['period_year'].apply(lambda x: (int(x.split()[1]), period_order[x.split()[0]]))

final_result = final_result.sort_values(by='sort_key').drop(columns='sort_key').reset_index(drop=True)


final_result
period_year_list = final_result['period_year'].tolist()  # First column
rating_list = final_result['rating'].tolist()
date1=period_year_list
rating1=rating_list
dare2 = [parse_date(date) for date in dare2]


df = pd.DataFrame({
    'date': dare2,
    'rating': rating2
})


df['year'] = df['date'].dt.year
df['month'] = df['date'].dt.month


df['period'] = df['month'].apply(getperiod)


avg_rating = df.groupby(['period', 'year'])['rating'].mean().reset_index()


avg_rating['period_year'] = avg_rating['period'] + ' ' + avg_rating['year'].astype(str)

final_result = avg_rating[['period_year', 'rating']]


final_result['sort_key'] = final_result['period_year'].apply(lambda x: (int(x.split()[1]), period_order[x.split()[0]]))

final_result = final_result.sort_values(by='sort_key').drop(columns='sort_key').reset_index(drop=True)

final_result
period_year_list = final_result['period_year'].tolist()  # First column
rating_list = final_result['rating'].tolist()
dare2=period_year_list
rating2=rating_list

fig, ax = plt.subplots(figsize=(10, 6))



ax.plot(dare2, rating2, marker='o', color='g', linestyle='-', linewidth=2, label="origina")
ax.plot(date1, rating1, marker='o', color='b', linestyle='-', linewidth=2, label="Restaurant 1")

all_dates = sorted(set(date1 + dare2)) 
ax.set_xticks(all_dates)  
ax.set_xticklabels(all_dates,rotation=45, ha='right')  # Rotate labels
# Customize the axes and ticks
 # Set limits to slightly expand around the min and max dates
ax.set_ylim(0, 6)  # Adjust y-limit based on your ratings

# Set labels and title
ax.set_xlabel('Date')
ax.set_ylabel('Rating')
ax.set_title('Restaurant Rating Trends')

# Add a legend
ax.legend()

# Show the plot
plt.grid(True, linestyle='--', alpha=0.7)  # Optional: Add a grid for better readability
plt.show()

image_path = os.path.join('static/', 'images/', 'comparison_plot.png')
if not os.path.exists('static/images'):
    os.makedirs('static/images')  # Create images folder if not exists

# Save the plot to the static folder
plt.savefig(image_path)

# Check if the image exists before rendering
